document.addEventListener('DOMContentLoaded', () => {
  const render = (selector, size, data) => {
    const margin = size.margin;
    const width = size.width - margin.left - margin.right;
    const height = size.height - margin.top - margin.bottom;

    const x = d3.scaleLinear()
      .domain(d3.extent(data, ({percip}) => percip))
      .range([0, width]);

    const y = d3.scaleBand()
      .domain(data.map(({year}) => year))
      .rangeRound([0, height])
      .padding(0.2);

    const xAxis = d3.axisBottom(x);

    const yAxis = d3.axisLeft(y)
      .tickSize(0);

    const svg = d3.select(selector)
      .attr('width', size.width)
      .attr('height', size.height);

    const chart = svg.append('g')
      .attr('transform', `translate(${ margin.left }, ${ margin.top })`);

    const bar = chart.selectAll('.bar')
      .data(data)
      .enter().append('rect')
        .attr('class', ({percip}) => `bar ${ percip < 0 ? 'negative': 'positive' }`)
        .attr('x', ({percip}) => x(Math.min(0, percip)))
        .attr('y', ({year}) => y(year))
        .attr('width', ({percip}) => Math.abs(x(percip) - x(0)))
        .attr('height', y.bandwidth());

    chart.append('g')
      .attr('transform', `translate(0, ${ height })`)
      .attr('class', 'axis x')
      .call(xAxis);

    chart.append('g')
      .attr('class', 'axis y')
      .attr('transform', `translate(${ x(0) }, 0)`)
      .call(yAxis);
  };

  fetch('data.json')
    .then(data => data.json())
    .then(data => {
      const settings = {
        width: 1000,
        height: 600,
        margin: {
          top: 20,
          right: 20,
          bottom: 30,
          left: 40
        }
      };

      render('#chart1', settings, data);
    });
});
