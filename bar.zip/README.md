D3 Bar Chart
============

From the tutorials:

  * [Let's make a bar chart](https://bost.ocks.org/mike/bar/)
  * [Let's make a bar chart, Part II](https://bost.ocks.org/mike/bar/2/)
  * [Let's make a bar chart, Part III](https://bost.ocks.org/mike/bar/3/)
  * [Bar chart with negative values](https://bl.ocks.org/mbostock/2368837)

We are using D3 v4 while the examples are in v3 so there are some API
changes to be aware of

Additional resources
--------------------

  * [D3 tutorials](https://github.com/d3/d3/wiki/Tutorials)