import * as d3 from 'd3';

//displaying the bar of data 
export default class BarDisplay{
    //creating a constructor 
    constructor(barData){
        this.w = 1300;
        this.h = 1900;
        this.padding = 5;
        this.dataset = barData.myData;
        console.log(barData);

        //creating an array to push our precipitation data into 
        this.allPrecip = [];

        for(let i = 0;i<this.dataset.length; i++){
            this.allPrecip.push(this.dataset[i].precipValue);
        }



        //calling the build chart function that we are going to write below
        this.buildChart();
    }

    //creating a buildChart function
    buildChart(){
    let svg = d3.select("#barSpace")
    .append("svg")
    .attr("width", this.w)
    .attr("height", this.h);

    //putting numbers on the x axis. 1970 to 2010
    let xScale = d3.scaleLinear()
    .domain([1970,2010])
    .range([0,1000]);
    
    //putting a range of numbers on the left y-axis. Min value to max value precipitation
    let yScale = d3.scaleLinear()
    .domain([67, -52])
    .range([-200,550]);
    
    //putting a range of numbers on the right y-axis. Min value to max value temperature
    let yScale1 = d3.scaleLinear()
    .domain([-2, 2])
    .range([400,0]);
    
    // Define the axes
    let x_axis = d3.axisBottom()
        .scale(xScale)
        .tickFormat(d3.format("d"))
        .tickPadding(350)
        
        
    let y_axis = d3.axisLeft()
        .scale(yScale);

    let y_axis2 = d3.axisRight()
        .scale(yScale1);

    
    
    //appending the group and inserting the dataset
    svg.append("g").selectAll(".bar")
    .data(this.dataset)

    let g = svg.append("g")
    .attr("transform", "translate(" + 100 + "," + 100 + ")");

     //appending the axes in the svg so they are visible and positioning them correctly on the screen
    g.append("g")
    .attr("transform", "translate(150, 100)")//19
    .call(y_axis).attr("color", "#1D2430").attr("font-size", "15")
    .append("text")
    .attr("fill", "#1D2430")
    .text("Precipitation").attr("font-weight", "bold")
    .attr("dx", "-12.1em")
    .attr("dy", "-5.1em")
    .attr("transform", "rotate(-90)")
    .attr("font-family","raleway")




    //creating the bar graph in respective to its precipitation scale. And then styling it
    g.selectAll(".bar")
    .data(this.dataset)
    .enter().append("rect")
    .attr("class", "bar")
    .attr("x", (d,i) => 150 + (i*25))
    .attr("y",function(d,i)
    {
        if(Math.sign(d.precipValue) == -1 ){ console.log(d.precipValue);return 301 }
        else { console.log("neg"+d.precipValue); return 300 - (d.precipValue*5)};
    })

    .attr("width",d => 20)
    .attr("height", d => 5 * Math.abs(d.precipValue))
    .style("fill", "green")
    .style("stroke", "#ffffff")


    //calling the x_axis and giving it the label of Year 
    g.append("g")
    .attr("transform", "translate("+165+ ", " + 300 +")")
    .call(x_axis).attr("color", "#1D2430").attr("font-size", "15")
    .append("text").attr("font-size", "16")
    .attr("fill", "#1D2430")
    .text("Year").attr("font-weight", "bold")
    .attr("dx", "31.28em")
    .attr("dy", "18em")
    .attr("font-family","raleway")
    


 


   //creating the legend so that the bar represents precipitation and the line graph represents the temperature scale
    svg.append("circle").attr("cx",300).attr("cy",130).attr("r", 6).style("fill", "#47a1a9 ")
    svg.append("circle").attr("cx",300).attr("cy",160).attr("r", 6).style("fill", "#ffa500")
    svg.append("text").attr("x", 320).attr("y", 130).text("Temperature").style("font-size", "15px").attr("font-family", "raleway").attr("alignment-baseline","middle")
    .style("fill", "#47a1a9")
    svg.append("text").attr("x", 320).attr("y", 160).text("Precipitation").style("font-size", "15px").attr("alignment-baseline","middle") .attr("font-family", "raleway")
    .style("fill", "#ffa500")     
    }
    

}
