//importing the BarDisplay and LineDisplay classes 
import BarDisplay from './BarDisplay';


//creating a class called Graphs
class Graphs{
    //creating a constructor with different variables 
    constructor(){    
        let barWidth= 400;
        let barHeight= 300;
        let barPadding= 2;
        let barHolder ="#barSpace";

    //calling the fetData function to fetch data from the json file
        this.fetchData();

    }

//fetching data from the json file
fetchData(){

     //fetch the data from the file 
    fetch('data.json')
    .then(data => data.json())
    .then(data => {

         //storing the data from the data.json file
        this.myData = data;
        console.log(data);

        //creating an instance of the barDisplay class and putting the data in the parameter
        let barGraph = new BarDisplay(this.myData);
        
    })
}

}

let bar = new Graphs();
